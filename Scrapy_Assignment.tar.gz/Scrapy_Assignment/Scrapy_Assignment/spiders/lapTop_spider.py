import scrapy
import re
from Scrapy_Assignment.items import ScrapyAssignmentItem


class LaptopSpider(scrapy.Spider):
    name = "laptop_spider"
    start_urls = [
        'http://www.mega.pk/product/laptop-specs-processor-i3/'
    ]

    def parse(self, response):
	item = ScrapyAssignmentItem()
	for laptop in response.xpath('//li[@class="col-xs-6 col-sm-4 col-md-4 col-lg-3"]'):
            	
		
		#response.xpath('//div[@class="col-md-10"]/h1[@class="cat-title"]/text()').re_first(r'^\w+\s*\w+')
                item["name"] = laptop.xpath('.//div[@id="lap_name_div"]/h3/a/text()').extract_first().encode('utf-8').strip()
		item["model"] = laptop.xpath('.//div[@id="lap_name_div"]/h3/a/text()').re_first(r'^\w+').encode('utf-8').strip()
	        item["title"] = laptop.xpath('.//ul[@class="detailer"]/li[1]/text()').re_first(r'core\s\w{2}|Core\s\w{2}')
		item["specs"] = laptop.xpath('.//ul[@class="detailer"]/li/text()').extract()
		item["price"] = laptop.xpath('.//div[@class="cat_price"]/text()').re(r'\d+')
		yield item
		              
           
	for href in response.xpath('//div[@class="col-xs-12 col-sm-6 col-md-4"]/a[@class="btn btn-default btn-block"]/@href'):
		yield response.follow(href,self.parse)
        
            
	
