
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import sessionmaker


engine = create_engine('mysql://root:1234@localhost:3306/laptopDB')
Base = declarative_base()
Session = sessionmaker(bind=engine)
Session = sessionmaker()
Session.configure(bind=engine)
session = Session()


class laptopTable(Base):
     __tablename__ = 'laptopTable'
     id = Column(Integer, primary_key=True)
     name = Column(String(1000))
     model = Column(String(1000))
     title = Column(String(1000))
     specs = Column(String(1000))
     price = Column(Integer)


class ScrapyAssignmentPipeline(object):
   
	    
	
    def process_item(self, item, spider):
       addLaptop = laptopTable(name = item["name"], model = item["model"], title =  item["title"], specs = ''.join(item["specs"]), price =int(''.join(item["price"])))
       session.add(addLaptop)
       session.commit()    

       return item
