from flask import Flask, jsonify
from flask.ext.sqlalchemy import SQLAlchemy
import re

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:1234@localhost:3306/laptopDB'
db = SQLAlchemy(app)


class LaptopTable(db.Model):
     __tablename__ = 'laptopTable'
     id = db.Column(db.Integer, primary_key=True)
     name = db.Column(db.String(1000))
     model = db.Column(db.String(1000))
     title = db.Column(db.String(1000))
     specs = db.Column(db.String(1000))
     price = db.Column(db.Integer)


@app.route('/laptop/all', methods=['GET'])
def allLaptops():  
    data = LaptopTable.query.all() 

    data_all = []

    for laptop in data:
        data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)

@app.route('/laptop/core-i3', methods=['GET'])
def getCorei3():  
    data = LaptopTable.query.filter_by(title="Core i3").all() 

    data_all = []

    for laptop in data:
        data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)

@app.route('/laptop/core-i5', methods=['GET'])
def getCorei5():  
    data = LaptopTable.query.filter_by(title="Core i5").all() 

    data_all = []

    for laptop in data:
        data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)

@app.route('/laptop/core-i7', methods=['GET'])
def getCorei7():  
    data = LaptopTable.query.filter_by(title="Core i7").all() 

    data_all = []

    for laptop in data:
        data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)

@app.route('/laptop/<laptopModel>', methods=['GET'])
def getbyModel(laptopModel):  
    data = LaptopTable.query.filter_by(model=laptopModel).all() 

    data_all = []

    for laptop in data:
        data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)

@app.route('/laptop/<int:initialPrice>/<int:finalPrice>', methods=['GET'])
def getbyprice(initialPrice,finalPrice):
     
    
    data = LaptopTable.query.all() 

    data_all = []

    for laptop in data:
	   if laptop.price >= initialPrice and laptop.price <= finalPrice:
              data_all.append([laptop.id, laptop.name, laptop.model, laptop.title, laptop.specs, laptop.price]) 

    return jsonify(laptop=data_all)



if __name__ == "__main__":  
    app.run()
